// script.js - Core JavaScript for LMS with AI Course Generation

// ============ AUTHENTICATION FUNCTIONS ============

// Student Registration
function registerStudent(event) {
    event.preventDefault();
    
    const name = document.getElementById('name')?.value;
    const email = document.getElementById('email')?.value;
    const password = document.getElementById('password')?.value;
    const confirmPassword = document.getElementById('confirmPassword')?.value;
    
    if (password !== confirmPassword) {
        showNotification('Passwords do not match!', 'danger');
        return false;
    }
    
    const students = JSON.parse(localStorage.getItem('lms_students')) || [];
    
    if (students.find(s => s.email === email)) {
        showNotification('Email already registered!', 'danger');
        return false;
    }
    
    const newStudent = {
        id: Date.now(),
        name: name,
        email: email,
        password: password,
        enrolledCourses: [],
        quizScores: {},
        registeredAt: new Date().toISOString()
    };
    
    students.push(newStudent);
    localStorage.setItem('lms_students', JSON.stringify(students));
    
    showNotification('Registration successful! Please login.', 'success');
    setTimeout(() => {
        window.location.href = 'login.html';
    }, 1500);
    
    return false;
}

// Student Login
function loginStudent(event) {
    event.preventDefault();
    
    const email = document.getElementById('email')?.value;
    const password = document.getElementById('password')?.value;
    
    const students = JSON.parse(localStorage.getItem('lms_students')) || [];
    const student = students.find(s => s.email === email && s.password === password);
    
    if (student) {
        localStorage.setItem('current_student', JSON.stringify(student));
        showNotification('Login successful!', 'success');
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 1000);
    } else {
        showNotification('Invalid email or password!', 'danger');
    }
    
    return false;
}

// Admin Login
function loginAdmin(event) {
    event.preventDefault();
    
    const username = document.getElementById('username')?.value;
    const password = document.getElementById('password')?.value;
    
    if (username === 'admin' && password === '123') {
        localStorage.setItem('admin_logged_in', 'true');
        showNotification('Admin login successful!', 'success');
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 1000);
    } else {
        showNotification('Invalid admin credentials!', 'danger');
    }
    
    return false;
}

// Check Auth
function checkStudentAuth() {
    const currentStudent = localStorage.getItem('current_student');
    if (!currentStudent) {
        window.location.href = 'login.html';
        return null;
    }
    return JSON.parse(currentStudent);
}

function checkAdminAuth() {
    const adminLoggedIn = localStorage.getItem('admin_logged_in');
    if (!adminLoggedIn) {
        window.location.href = 'login.html';
        return false;
    }
    return true;
}

// Logout - Redirect to Home Page (index.html) - FIXED PATH
function logout() {
    // Clear all session data
    localStorage.removeItem('current_student');
    localStorage.removeItem('admin_logged_in');
    
    // Show notification
    showNotification('Logged out successfully! Redirecting to home page...', 'success');
    
    // Get the current path to determine how many levels up we need to go
    const currentPath = window.location.pathname;
    let homePath = '';
    
    // Determine the correct path to index.html based on current location
    if (currentPath.includes('/admin/')) {
        homePath = '../index.html';
    } else if (currentPath.includes('/student/')) {
        homePath = '../index.html';
    } else {
        homePath = 'index.html';
    }
    
    // Redirect to main index page after short delay
    setTimeout(() => {
        window.location.href = homePath;
    }, 1000);
}

// ============ AI COURSE GENERATOR ============

// AI-Powered Course Content Generator
class AICourseGenerator {
    static async generateFullCourse(courseName) {
        // Simulate AI processing
        return new Promise((resolve) => {
            setTimeout(() => {
                const course = this.createCourseFromName(courseName);
                resolve(course);
            }, 1500);
        });
    }
    
    static createCourseFromName(courseName) {
        const topics = this.extractTopics(courseName);
        const description = this.generateDescription(courseName, topics);
        const category = this.detectCategory(courseName);
        const difficulty = this.detectDifficulty(courseName);
        const quiz = this.generateAIQuiz(courseName, topics, difficulty);
        const learningOutcomes = this.generateLearningOutcomes(courseName, topics);
        const prerequisites = this.generatePrerequisites(courseName);
        
        return {
            title: courseName,
            description: description,
            category: category,
            difficulty: difficulty,
            quiz: quiz,
            learningOutcomes: learningOutcomes,
            prerequisites: prerequisites,
            topics: topics,
            duration: this.estimateDuration(courseName),
            rating: 4.5,
            studentsEnrolled: 0
        };
    }
    
    static extractTopics(courseName) {
        const keywords = {
            'web': ['HTML', 'CSS', 'JavaScript', 'React', 'Responsive Design', 'Web APIs'],
            'python': ['Variables', 'Functions', 'OOP', 'Libraries', 'Data Structures', 'File Handling'],
            'javascript': ['ES6', 'DOM Manipulation', 'Async/Await', 'Promises', 'Arrays', 'Objects'],
            'react': ['Components', 'Props', 'State', 'Hooks', 'Redux', 'Router'],
            'data science': ['Pandas', 'NumPy', 'Matplotlib', 'Machine Learning', 'Statistics'],
            'machine learning': ['Supervised Learning', 'Unsupervised Learning', 'Neural Networks', 'TensorFlow'],
            'business': ['Marketing', 'Finance', 'Strategy', 'Leadership', 'Operations'],
            'design': ['UI Design', 'UX Research', 'Figma', 'Prototyping', 'Color Theory'],
            'marketing': ['SEO', 'Social Media', 'Content Strategy', 'Analytics', 'Email Marketing']
        };
        
        const lowerName = courseName.toLowerCase();
        let extractedTopics = [];
        
        for (const [key, topics] of Object.entries(keywords)) {
            if (lowerName.includes(key)) {
                extractedTopics = topics.slice(0, 5);
                break;
            }
        }
        
        if (extractedTopics.length === 0) {
            extractedTopics = [
                'Introduction to ' + courseName,
                'Core Concepts',
                'Advanced Topics',
                'Practical Applications',
                'Best Practices',
                'Real-world Projects'
            ];
        }
        
        return extractedTopics;
    }
    
    static generateDescription(courseName, topics) {
        const descriptions = [
            `Master ${courseName} from scratch with our comprehensive course designed for beginners and professionals.`,
            `Learn ${courseName} through hands-on projects and real-world applications. Perfect for career advancement.`,
            `Become an expert in ${courseName} with this all-in-one course covering everything from basics to advanced concepts.`,
            `Unlock your potential with ${courseName}. This course includes practical exercises, quizzes, and real projects.`
        ];
        
        let description = descriptions[Math.floor(Math.random() * descriptions.length)];
        description += ` You'll learn: ${topics.slice(0, 3).join(', ')}, and much more!`;
        
        return description;
    }
    
    static detectCategory(courseName) {
        const lower = courseName.toLowerCase();
        if (lower.includes('web') || lower.includes('html') || lower.includes('css') || lower.includes('javascript') || lower.includes('react')) {
            return 'Web Development';
        } else if (lower.includes('python') || lower.includes('java') || lower.includes('programming') || lower.includes('code')) {
            return 'Programming';
        } else if (lower.includes('data') || lower.includes('machine') || lower.includes('ai')) {
            return 'Data Science';
        } else if (lower.includes('business') || lower.includes('management')) {
            return 'Business';
        } else if (lower.includes('design') || lower.includes('ui') || lower.includes('ux')) {
            return 'Design';
        } else if (lower.includes('marketing')) {
            return 'Marketing';
        }
        return 'Technology';
    }
    
    static detectDifficulty(courseName) {
        const lower = courseName.toLowerCase();
        if (lower.includes('advanced') || lower.includes('expert') || lower.includes('master')) {
            return 'Advanced';
        } else if (lower.includes('intermediate') || lower.includes('professional')) {
            return 'Intermediate';
        }
        return 'Beginner';
    }
    
    static generateAIQuiz(courseName, topics, difficulty) {
        const questions = [];
        const questionCount = 6;
        
        for (let i = 0; i < questionCount; i++) {
            const topic = topics[i % topics.length];
            const question = {
                question: this.generateQuestion(courseName, topic, i),
                options: this.generateOptions(courseName, topic, i),
                answer: Math.floor(Math.random() * 4)
            };
            questions.push(question);
        }
        
        return questions;
    }
    
    static generateQuestion(courseName, topic, index) {
        const questions = [
            `What is the most important concept in ${topic}?`,
            `How does ${topic} apply to ${courseName}?`,
            `What are the best practices for ${topic}?`,
            `Why is ${topic} crucial for mastering ${courseName}?`,
            `What are the common challenges in ${topic}?`,
            `How can you optimize your approach to ${topic}?`
        ];
        return questions[index % questions.length];
    }
    
    static generateOptions(courseName, topic, index) {
        const baseOptions = [
            ['Understanding fundamentals', 'Advanced techniques', 'Practical application', 'Theoretical knowledge'],
            ['Best practices', 'Common mistakes', 'Optimization', 'Debugging'],
            ['Real-world examples', 'Case studies', 'Hands-on practice', 'Documentation'],
            ['Team collaboration', 'Individual work', 'Mentorship', 'Self-learning']
        ];
        return baseOptions[index % baseOptions.length];
    }
    
    static generateLearningOutcomes(courseName, topics) {
        return topics.slice(0, 4).map(topic => `Master ${topic} concepts and apply them in real projects`);
    }
    
    static generatePrerequisites(courseName) {
        const lower = courseName.toLowerCase();
        if (lower.includes('advanced') || lower.includes('expert')) {
            return ['Basic understanding of programming', 'Familiarity with core concepts', 'Computer with internet access'];
        }
        return ['No prior knowledge required', 'Willingness to learn', 'Computer with internet access'];
    }
    
    static estimateDuration(courseName) {
        const lower = courseName.toLowerCase();
        if (lower.includes('advanced')) return '15 hours';
        if (lower.includes('intermediate')) return '10 hours';
        return '6 hours';
    }
}

// Course Model
class Course {
    constructor(id, title, description, category, difficulty, quiz, instructor, thumbnail, learningOutcomes, prerequisites, duration) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.category = category;
        this.difficulty = difficulty;
        this.quiz = quiz;
        this.instructor = instructor || 'AI Instructor';
        this.thumbnail = thumbnail || '';
        this.learningOutcomes = learningOutcomes || [];
        this.prerequisites = prerequisites || [];
        this.duration = duration || '6 hours';
        this.createdAt = new Date().toISOString();
        this.enrolledStudents = [];
        this.rating = 4.5;
    }
}

// Course Management
function getAllCourses() {
    return JSON.parse(localStorage.getItem('lms_courses')) || [];
}

function saveCourse(course) {
    const courses = getAllCourses();
    courses.push(course);
    localStorage.setItem('lms_courses', JSON.stringify(courses));
    return course;
}

function updateCourse(courseId, updatedCourse) {
    const courses = getAllCourses();
    const index = courses.findIndex(c => c.id === courseId);
    if (index !== -1) {
        courses[index] = updatedCourse;
        localStorage.setItem('lms_courses', JSON.stringify(courses));
    }
}

function deleteCourse(courseId) {
    let courses = getAllCourses();
    courses = courses.filter(c => c.id !== courseId);
    localStorage.setItem('lms_courses', JSON.stringify(courses));
    
    const students = JSON.parse(localStorage.getItem('lms_students')) || [];
    students.forEach(student => {
        if (student.quizScores && student.quizScores[courseId]) {
            delete student.quizScores[courseId];
        }
    });
    localStorage.setItem('lms_students', JSON.stringify(students));
}

// AI-Powered Course Creation
async function createAICourse(courseName) {
    showNotification('🤖 AI is generating your course...', 'info');
    
    const generated = await AICourseGenerator.generateFullCourse(courseName);
    
    const newCourse = new Course(
        Date.now(),
        generated.title,
        generated.description,
        generated.category,
        generated.difficulty,
        generated.quiz,
        'AI Instructor',
        '',
        generated.learningOutcomes,
        generated.prerequisites,
        generated.duration
    );
    
    saveCourse(newCourse);
    showNotification(`✅ Course "${courseName}" created successfully with AI!`, 'success');
    
    return newCourse;
}

// ============ QUIZ FUNCTIONS ============

function saveQuizScore(studentId, courseId, score, totalQuestions, answers) {
    const students = JSON.parse(localStorage.getItem('lms_students')) || [];
    const studentIndex = students.findIndex(s => s.id === studentId);
    
    if (studentIndex !== -1) {
        if (!students[studentIndex].quizScores) {
            students[studentIndex].quizScores = {};
        }
        if (!students[studentIndex].quizScores[courseId]) {
            students[studentIndex].quizScores[courseId] = [];
        }
        
        students[studentIndex].quizScores[courseId].push({
            score: score,
            total: totalQuestions,
            percentage: (score / totalQuestions) * 100,
            answers: answers,
            date: new Date().toISOString()
        });
        
        localStorage.setItem('lms_students', JSON.stringify(students));
        
        const currentStudent = JSON.parse(localStorage.getItem('current_student'));
        if (currentStudent && currentStudent.id === studentId) {
            localStorage.setItem('current_student', JSON.stringify(students[studentIndex]));
        }
    }
}

function getStudentQuizScores(studentId, courseId) {
    const students = JSON.parse(localStorage.getItem('lms_students')) || [];
    const student = students.find(s => s.id === studentId);
    if (student && student.quizScores && student.quizScores[courseId]) {
        return student.quizScores[courseId];
    }
    return [];
}

function enrollStudentInCourse(studentId, courseId) {
    const students = JSON.parse(localStorage.getItem('lms_students')) || [];
    const studentIndex = students.findIndex(s => s.id === studentId);
    
    if (studentIndex !== -1) {
        if (!students[studentIndex].enrolledCourses) {
            students[studentIndex].enrolledCourses = [];
        }
        if (!students[studentIndex].enrolledCourses.includes(courseId)) {
            students[studentIndex].enrolledCourses.push(courseId);
            localStorage.setItem('lms_students', JSON.stringify(students));
            
            const currentStudent = JSON.parse(localStorage.getItem('current_student'));
            if (currentStudent && currentStudent.id === studentId) {
                localStorage.setItem('current_student', JSON.stringify(students[studentIndex]));
            }
            return true;
        }
    }
    return false;
}

// ============ UTILITY FUNCTIONS ============

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

function showNotification(message, type = 'info') {
    // Remove any existing notifications
    const existingNotifications = document.querySelectorAll('.alert-notification');
    existingNotifications.forEach(notification => notification.remove());
    
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show alert-notification`;
    notification.style.cssText = 'position: fixed; top: 80px; right: 20px; z-index: 9999; min-width: 300px; animation: slideInRight 0.3s ease; box-shadow: 0 5px 15px rgba(0,0,0,0.2);';
    notification.innerHTML = `
        <i class="bi ${type === 'success' ? 'bi-check-circle' : type === 'danger' ? 'bi-exclamation-triangle' : 'bi-info-circle'} me-2"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    document.body.appendChild(notification);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        if (notification && notification.remove) {
            notification.remove();
        }
    }, 3000);
}

function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

// Initialize demo data
function initializeDemoData() {
    let courses = getAllCourses();
    if (courses.length === 0) {
        const demoCourses = [
            { name: 'Web Development Fundamentals', category: 'Technology', difficulty: 'Beginner' },
            { name: 'Python Programming', category: 'Programming', difficulty: 'Intermediate' },
            { name: 'Data Science Basics', category: 'Data Science', difficulty: 'Beginner' }
        ];
        
        // Use setTimeout to create courses one by one
        demoCourses.forEach(async (demo, index) => {
            setTimeout(async () => {
                await createAICourse(demo.name);
            }, index * 500);
        });
    }
    
    let students = JSON.parse(localStorage.getItem('lms_students')) || [];
    if (students.length === 0) {
        const demoStudent = {
            id: Date.now(),
            name: 'Demo Student',
            email: 'student@example.com',
            password: '123456',
            enrolledCourses: [],
            quizScores: {},
            registeredAt: new Date().toISOString()
        };
        students.push(demoStudent);
        localStorage.setItem('lms_students', JSON.stringify(students));
    }
}

// Add CSS animation
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    .alert-notification {
        cursor: pointer;
    }
    
    .alert-notification:hover {
        transform: translateX(-5px);
        transition: transform 0.2s;
    }
`;
document.head.appendChild(style);

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    initializeDemoData();
});

// Export functions for global use
window.logout = logout;
window.registerStudent = registerStudent;
window.loginStudent = loginStudent;
window.loginAdmin = loginAdmin;
window.createAICourse = createAICourse;
window.enrollStudentInCourse = enrollStudentInCourse;
window.getAllCourses = getAllCourses;
window.deleteCourse = deleteCourse;
window.showNotification = showNotification;
window.escapeHtml = escapeHtml;
window.formatDate = formatDate;