const router = require('express').Router();
const Book = require('../models/Book');
const auth = require('../middleware/auth');

router.post('/add', auth, async (req, res) => {
  if (req.user.role !== 'librarian')
    return res.send("Access Denied");

  const book = new Book(req.body);
  await book.save();
  res.send(book);
});

router.delete('/:id', auth, async (req, res) => {
  if (req.user.role !== 'librarian')
    return res.send("Access Denied");

  await Book.findByIdAndDelete(req.params.id);
  res.send("Deleted");
});

router.get('/', async (req, res) => {
  const books = await Book.find();
  res.json(books);
});

router.post('/borrow/:id', auth, async (req, res) => {
  const book = await Book.findById(req.params.id);
  book.available = false;
  book.borrowedBy = req.user.id;
  book.returnDate = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
  await book.save();
  res.send(book);
});

router.post('/return/:id', auth, async (req, res) => {
  const book = await Book.findById(req.params.id);
  book.available = true;
  book.borrowedBy = null;
  book.returnDate = null;
  await book.save();
  res.send(book);
});

module.exports = router;