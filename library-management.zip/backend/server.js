const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

mongoose.connect("mongodb://127.0.0.1:27017/library");

app.use('/api/auth', require('./routes/auth'));
app.use('/api/books', require('./routes/books'));

app.listen(5000, () => console.log("Server running on port 5000"));