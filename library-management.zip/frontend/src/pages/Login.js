import axios from 'axios';
import { useState } from 'react';

export default function Login() {
  const [data, setData] = useState({ email: '', password: '' });

  const login = async () => {
    const res = await axios.post('http://localhost:5000/api/auth/login', data);
    localStorage.setItem('token', res.data.token);

    if (res.data.role === 'librarian')
      window.location = '/librarian';
    else
      window.location = '/user';
  };

  return (
    <div style={{textAlign:'center',marginTop:'100px'}}>
      <h2>Login</h2>
      <input placeholder="Email" onChange={e => setData({...data,email:e.target.value})}/>
      <br/>
      <input type="password" placeholder="Password" onChange={e => setData({...data,password:e.target.value})}/>
      <br/>
      <button onClick={login}>Login</button>
    </div>
  );
}