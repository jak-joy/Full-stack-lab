import axios from 'axios';
import { useEffect, useState } from 'react';

export default function UserDashboard() {
  const [books, setBooks] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/books')
      .then(res => setBooks(res.data));
  }, []);

  const borrow = (id) => {
    axios.post(`http://localhost:5000/api/books/borrow/${id}`, {}, {
      headers: { Authorization: localStorage.getItem('token') }
    }).then(() => window.location.reload());
  };

  return (
    <div>
      <h2>User Dashboard</h2>
      {books.map(book => (
        <div key={book._id}>
          {book.title} - {book.available ? "Available" : "Borrowed"}
          {book.available && <button onClick={() => borrow(book._id)}>Borrow</button>}
        </div>
      ))}
    </div>
  );
}