import axios from 'axios';
import { useEffect, useState } from 'react';

export default function LibrarianDashboard() {
  const [books, setBooks] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/books')
      .then(res => setBooks(res.data));
  }, []);

  return (
    <div>
      <h2>Librarian Dashboard</h2>
      {books.map(book => (
        <div key={book._id}>
          {book.title} - {book.available ? "Available" : "Issued"}
        </div>
      ))}
    </div>
  );
}